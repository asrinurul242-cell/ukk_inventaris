<?php
session_start();
include "config/koneksi.php";

$user = $_SESSION['username'] ?? '';
$level = $_SESSION['level'] ?? '';

$P = $_GET['P'] ?? 'login';

// Jika user belum login, paksa ke halaman login
if (empty($user)) {
    $P = 'login';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Aplikasi Inventaris</title>

    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>


<body>
    <?php if (!empty($user)) { ?>
    <!-- Navbar untuk user yang sudah login -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Aplikasi Inventaris</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <?php if ($level == "1") { ?>
                    <li><a href="?P=list_barang">Daftar Inventaris</a></li>
                    <li><a href="?P=user">user</a></li>
                    <li><a href="?P=peminjaman">Peminjaman</a></li>
                    <li><a href="?P=pengembalian">Pengembalian</a></li>
                    <li><a href="?P=laporan">Laporan</a></li>
                    <?php } ?>
                    <?php if ($level == "2") { ?>
                        <li><a href="?P=user">user</a></li>
                    <li><a href="?P=peminjaman">Peminjaman</a></li>
                    <li><a href="?P=pengembalian">Pengembalian</a></li>
                    <?php } ?>
                    <?php if ($level == "3") { ?>
                        <li><a href="?P=user">user</a></li>
                    <li><a href="?P=peminjaman">Peminjaman</a></li>
                    <?php } ?>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                            aria-expanded="false">
                            <?= $user ?> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="page/keluar.php">Keluar</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php } ?>

    <div class="container">
        <?php
    switch ($P) {
        case 'login':
            include "page/login.php";
            break;
        case 'list_barang':
            include "page/list_barang.php";
            break;
        case 'tambah_barang':
            include "page/tambah_barang.php";
            break;
        case 'edit_barang':
            include "page/edit_barang.php";
            break;
        case 'peminjaman':
            include "page/peminjaman.php";
            break;
        case 'pengembalian':
            include "page/pengembalian.php";
            break;
        case 'detail_pengembalian':
            include "page/detail_pengembalian.php";
            break;
        case 'laporan':
            include "page/laporan.php";
            break;
        case 'home':
            include "page/home.php";
            break;
            case 'hapus':
                include "page/hapus.php";
                break;
                case 'user':
                include "page/user.php";
                break;
                    
        default:
            include "page/login.php";
            break;
    }
    ?>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
</body>

</html>
<script type="text/javascript">
    $(document).on('click','#cetak',function(){
    var tgl_awal = $("#tgl_awal").val();
    var tgl_Sampai = $("#tgl_Sampai").val();
    window.open('page/cetak_laporan.php?tgl_awal='+tgl_awal+"$tgl_Sampai="+tgl_Sampai, '_blank');
    });
    
</script>