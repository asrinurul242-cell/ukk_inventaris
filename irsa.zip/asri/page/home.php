<div class="jumbotron">
    <h1>Selamat Datang,
        <?= $user ?>!
    </h1>
    <p>Selamat datang di <strong>Aplikasi Inventaris Barang</strong>.</p>
    <p>
        Aplikasi ini merupakan bagian dari uji kompetensi siswa kelas XII RPL
        dan bertujuan untuk melatih pemahaman dalam pengembangan aplikasi berbasis web.
    </p>
</div>