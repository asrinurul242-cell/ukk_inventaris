<?php
$hari_ini = date('Y-m-d');
?>
<div class="col-lg-12">
    <div class="panel panel-primary">
        <div class="panel-heading">Laporan Peminjaman Alat</div>
        <div class="panel-body">

            <form action="" method="get" class="form-inline">
                <input type="hidden" name="P" value="laporan">
                <div class=" form-group">
                    <label>Tanggal Awal</label><br>
                    <input type="date" name="tglDari" id="TglAwal" class="form-control"
                        value="<?= !empty($_GET['tglDari']) ? $_GET['tglDari'] : $hari_ini?>">
                </div>

                <div class="form-group">
                    <label>Tanggal Sampai</label><br>
                    <input type="date" id="Tgl_sampai" name="tgl_sampai" class="form-control"
                        value="<?= !empty($_GET['tgl_sampai']) ? $_GET['tgl_sampai'] : $hari_ini ?>">

                </div>

                <div class="form-group"><br>
                    <input type="submit" class="btn btn-sm btn-primary" name="cari" value=" Filter">
                    <button type="button" class="btn btn-sm btn-success" id="cetak">Cetak Laporan</button>
                </div>
            </form>

            <hr>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Peminjam</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Tgl. Peminjaman</th>
                        <th>Tgl. Pengembalian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                     $cari = '';
                    @$tglDari = $_GET['tglDari'];
                    @$tgl_Sampai = $_GET['tgl_Sampai'];

                     if (!empty($tglDari)) {
                     $cari .="and tanggal_pinjam >= '".$tglDari."'";
                     }
                     if (!empty($tgl_Sampai)) {
                      $cari .="and tanggal_pinjam <= '".$tgl_Sampai."'";
                      }
                     //if (empty($tglDari) && ($tgl_Sampai)) {
                     // $cari .="and tanggal_pinjam) >= '".$tglDari."'and tanggal_pinjam <='".$tgl_Sampai."'"
                     //}
                     $sql =  "SELECT *,detail_pinjam.jumlah as  jumlah FROM detail_pinjam left join peminjaman on peminjaman.id_peminjaman = detail_pinjam.id_peminjaman left join barang on barang.id_barang = detail_pinjam.id_barang 
                     Left Join peminjam on peminjam.id_peminjam = peminjaman.id_peminjam WHERE 1=1 $cari";

                     $query = mysqli_query($koneksi, $sql);
                     $cek = mysqli_num_rows($query);
                     
                     if ($cek > 0) {
                      $no = 1;
                     while ($data = mysqli_fetch_array($query)) {
                     ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data['nama_peminjam'] ?></td>
                        <td><?= $data['nama'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                        <td><?= $data['tanggal_pinjam'] ?></td>
                        <td><?= $data['tanggal_kembali'] ?></td>
                    </tr>
                    <?php
                   }
                    }else {
                     ?>
                    <tr>
                        <td colspan="6">Tidak Ada Data </td>
                    </tr>
                    <?php
                    }
                    ?>
                    <!--<tr>
                        <td>1</td>
                        <td>Asri</td>
                        <td>Laptop</td>
                        <td>10</td>
                        <td>16-01-2026</td>
                        <td>00-00-0000</td>
                        </tr>-->
                </tbody>
            </table>

        </div>
    </div>
</div>