<?php
$id_barang = $_GET['id_barang'];
if (empty($id_barang)) {
        ?>
<script type="text/javascript">
window.location.href = "?P=list_barang";
</script>
<?php
}
$sql = "SELECT *,barang.keterangan as ket FROM barang LEFT JOIN ruang ON ruang.id_ruang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori WHERE 
id_barang = '$id_barang' ";
$query = mysqli_query($koneksi, $sql);
$cek = mysqli_num_rows($query);

if ($cek > 0) {
        $data = mysqli_fetch_array($query);
}else{
        $data = NULL;
}


?>
<div class="row">
    <h2>Edit Barang</h2>
    <hr>
    <div class="col-lg-4">
        <div class="panel panel-primary">
            <div class="panel-heading">Edit Barang Pinjaman</div>
            <div class="panel-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="">Kode Barang</label>
                        <input type="text" class="form-control" name="kode_barang" value="<?= $data['kode_barang']?>">
                    </div>
                    <div class="form-group">
                        <label for="">Nama Barang</label>
                        <input type="text" class="form-control" name="nama" value="<?= $data['nama']?>">
                    </div>
                    <div class=" form-group">
                        <label for="">Kondisi</label>
                        <select name="kondisi" id="" class="form-control">
                            <option value="<?= $data ['kondisi']?>" name="kondisi" class="form-control">
                                <?= $data ['kondisi']?>
                            </option>
                            <option value="Baik" name="" class="form-control">Baik</option>
                            <option value="Rusak" name="" class="form-control">Rusak</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Jumlah</label>
                        <input type="number" class="form-control" name="jumlah" value="<?= $data['jumlah']?>">
                    </div>
                    <div class="form-group">
                        <label>Kategori Barang</label>
                        <select name="id_kategori" class="form-control">
                            <option value="<?= $data['id_kategori'] ?>">
                                <?= $data['nama_kategori'] ?>
                            </option>
                            <?php
        $sql_kategori = "SELECT * FROM kategori";
        $q_kategori = mysqli_query($koneksi, $sql_kategori);
        while ($kat = mysqli_fetch_array($q_kategori)) {
            ?>
                            <option value="<?= $kat['id_kategori'] ?>">
                                <?= $kat['nama_kategori'] ?>
                            </option>
                            <?php
        }
        ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Ruang</label>
                        <select name="id_ruang" class="form-control">
                            <option value="<?= $data['id_ruang'] ?>">
                                <?= $data['nama_ruang'] ?>
                            </option>
                            <?php
    $sql_ruang = "SELECT * FROM ruang";
    $q_ruang=mysqli_query($koneksi, $sql_ruang);
    while ($ruang =mysqli_fetch_array($q_ruang)){
        ?>
                            <option value="<?= $ruang ['id_ruang']?>"><?= $ruang ['nama_ruang']?></option>
                            <?php
    }
     ?>

                        </select>
                        <label for="">Keterangan</label>
                        <?php
                            
                            ?>
                        <textarea name="ket" id="" cols="30" rows="10" class="form-control"
                            value="<?= $data['ket']?>"><?= $data['ket']?></textarea>
                    </div>
                    <div class=" form-group">
                       <button 
    type="submit"
    class="btn btn-md btn-primary"
    name="simpan"
    onclick="return confirm('Pastikan barang sudah benar. Klik OK untuk menyimpan perubahan.')">
    Simpan
</button>

                        <a href="?P=list_barang" class="btn btn-md btn-default">Kembali</a>
                    </div>
                </form>
                <?php
              if (isset($_POST['simpan'])) {

                $kode_barang = $_POST['kode_barang'];
                $nama        = $_POST['nama'];
                $kondisi     = $_POST['kondisi'];
                $jumlah      = $_POST['jumlah'];
                $id_kategori = $_POST['id_kategori'] ?? '';
                $id_ruang    = $_POST['id_ruang'];
                $ket         = $_POST['ket'];
               
                $sql_update = "UPDATE barang SET 
                kode_barang='$kode_barang',
                nama='$nama',
                kondisi='$kondisi',
                jumlah='$jumlah',
                id_kategori='$id_kategori',
                id_ruang='$id_ruang',
                keterangan='$ket'
                WHERE id_barang='$id_barang'";
           
               $q_update = mysqli_query($koneksi,$sql_update);
            if ($q_update) {
                ?>
                <script type="text/javascript">
                window.location.href = "?P=list_barang"
                </script>
                <?php
                }else{
                    ?>
                <div class="alert alert-danger ">
                    Barang Gagal Di Update!
                </div>
                <?php
                }
                }
                ?>
            </div>

        </div>



    </div>
</div>