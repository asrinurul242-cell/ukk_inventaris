<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Inventaris</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body style="padding-top:0; background: var(--surface-2);">
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Inventaris</h2>
            <a href="#">🏠&nbsp; Dashboard</a>
            <a href="#">📦&nbsp; Barang</a>
            <a href="#">🤝&nbsp; Peminjaman</a>
            <a href="#">↩️&nbsp; Pengembalian</a>
            <a href="#">📊&nbsp; Laporan</a>
        </div>

        <!-- Konten Utama -->
        <div class="main-content">
            <h1>Dashboard Inventaris</h1>
            <p style="color:var(--text-muted); margin-bottom:28px; font-size:14px;">Selamat datang kembali! Berikut ringkasan data hari ini.</p>

            <!-- Stat Cards -->
            <div class="stats-row">
                <div class="stat-card">
                    <div class="stat-label">Total Barang</div>
                    <div class="stat-value">48</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Sedang Dipinjam</div>
                    <div class="stat-value">5</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Dikembalikan</div>
                    <div class="stat-value">12</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Peminjam</div>
                    <div class="stat-value">20</div>
                </div>
            </div>

            <!-- Tabel Pengembalian -->
            <div class="card">
                <h3 style="font-family:'Playfair Display',serif; font-size:18px; color:var(--pink-deep); margin-bottom:18px;">
                    ✦ Daftar Pengembalian Terbaru
                </h3>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Peminjam</th>
                            <th>Barang</th>
                            <th>Tgl. Pinjam</th>
                            <th>Tgl. Kembali</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Asri Nurul</td>
                            <td>Laptop</td>
                            <td>10-02-2026</td>
                            <td>11-02-2026</td>
                            <td><span class="label label-success">Kembali</span></td>
                            <td>
                                <button class="button edit">Edit</button>
                                <button class="button delete">Hapus</button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Fauziah</td>
                            <td>Proyektor</td>
                            <td>10-02-2026</td>
                            <td>12-02-2026</td>
                            <td><span class="label label-warning">Dipinjam</span></td>
                            <td>
                                <button class="button edit">Edit</button>
                                <button class="button delete">Hapus</button>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Reni Anggraeni</td>
                            <td>Kamera DSLR</td>
                            <td>09-02-2026</td>
                            <td>11-02-2026</td>
                            <td><span class="label label-danger">Konfirmasi</span></td>
                            <td>
                                <button class="button edit">Edit</button>
                                <button class="button delete">Hapus</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
