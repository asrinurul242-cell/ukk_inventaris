<?php
if (!empty($user)) {
    ?>
<script type="text/javascript">
window.location.href = "?P=home";
</script>
<?php
}
?>


<div class="login-area">
    <div class="login-card text-center">
        <div class="login-icon">🍽️</div>
        <h3> Inventaris Barang</h3>
        <p>Silakan login untuk mengelola peminjaman</p>

        <form method="post">
            <div class="form-group text-left">
                <label>Username</label>
                <input type="text" name="username" class="form-control"
                       placeholder="Masukkan username" required>
            </div>

            <div class="form-group text-left">
                <label>Password</label>
                <input type="password" name="password" class="form-control"
                       placeholder="Masukkan password" required>
            </div>

            <button type="submit" name="masuk"
                    class="btn btn-blue btn-block">
                Masuk
            </button>
        </form>
    </div>
</div>

<?php
if (isset($_POST['masuk'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM petugas WHERE username = '$username'";
    $query = mysqli_query($koneksi, $sql);
    $cek = mysqli_num_rows($query);

    if ($cek > 0) {
        $data = mysqli_fetch_array($query);
        $pass_db = $data['password'];

        if ($password == $pass_db) {
            $_SESSION['username'] = $username;
$_SESSION['level'] = $data['id_level'];
$_SESSION['id_peminjam'] = $data['id_petugas'];

            ?>
<script>
window.location.href = '?P=home';
</script>;
<?php
        } else {

?>
<div class="alert alert-warning alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
    <strong>Maaf</strong> password yang anda masukan salah
</div>

<?php
            
        }
        
        
}else{
    ?>
<div class="alert alert-warning alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
    <strong>GAGAL!</strong>Maaf,username atau password yang anda masukan salah
</div>

<?php
}


}
?>