<?php
include "../config/koneksi.php";

$id_barang = $_GET['id_barang'];
$sql = "DELETE FROM barang WHERE id_barang='$id_barang'";
$query = mysqli_query($koneksi, $sql);

if ($query) {
    header("Location: ../index.php?P=list_barang");
} else {
    echo "Gagal menghapus data";
}
exit;