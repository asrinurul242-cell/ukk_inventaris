<?php

$sql = "SELECT max(id_peminjaman) as maxKode FROM peminjaman";
$query = mysqli_query($koneksi, $sql);
$data = mysqli_fetch_array($query);
$id_peminjaman = $data['maxKode'];

@$noUrut = (int) substr($id_peminjaman, 3, 3);
$noUrut++;

$char = "PMJ";
$KodePeminjaman = $char . sprintf("%03s", $noUrut);

?>

<div class="row">
    <h2>
    <center>PEMINJAMAN INVENTARIS</center>
    <hr>
</h2>

    <div class="col-lg-3">
        <div class="panel panel-primary">
            <div class="panel-heading">Peminjaman</div>
            <div class="panel-body">

                <form action="" method="post">
                    <div class="form-group">
                        <label>Kode Peminjaman</label>
                        <input type="text" class="form-control" name="id_peminjaman"
                               value="<?= $KodePeminjaman ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Nama Peminjam</label>
                        <select name="id_peminjam" class="form-control">
                            <option value="">- PILIH -</option>
                            <?php
                            $sql_peminjam = "SELECT * FROM peminjam";
                            $q_peminjam = mysqli_query($koneksi, $sql_peminjam);
                            while ($peminjam = mysqli_fetch_array($q_peminjam)) {
                            ?>
                                <option value="<?= $peminjam['id_peminjam'] ?>">
                                    <?= $peminjam['nama_peminjam'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Pilih Barang</label>
                        <select name="id_barang" class="form-control">
                            <option value="">- PILIH -</option>
                            <?php
                            $sql_barang = "SELECT * FROM barang";
                            $q_barang = mysqli_query($koneksi, $sql_barang);
                            while ($barang = mysqli_fetch_array($q_barang)) {
                            ?>
                                <option value="<?= $barang['id_barang'] ?>">
                                    <?= $barang['nama'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Jumlah</label>
                        <input type="number" class="form-control" name="jumlah">
                    </div>

                    <div class="form-group">
                        <button class="btn btn-md btn-primary" name="simpan">Simpan</button>
                    </div>
                </form>

            </div>

<?php
if (isset($_POST['simpan'])) {

    $id_peminjaman = $_POST['id_peminjaman'];
    $id_peminjam   = $_POST['id_peminjam'];
    $id_barang     = $_POST['id_barang'];
    $jumlah        = $_POST['jumlah'];

    mysqli_begin_transaction($koneksi);

    $cekStok = mysqli_query(
        $koneksi,
        "SELECT jumlah FROM barang WHERE id_barang='$id_barang' FOR UPDATE"
    );
    $dataStok = mysqli_fetch_array($cekStok);

    if ($jumlah > $dataStok['jumlah']) {
        echo "<script>alert('Stok tidak mencukupi! Stok tersedia: {$dataStok['jumlah']}');window.history.back();</script>";
        exit;
    }

    $sql_peminjaman = "INSERT INTO peminjaman SET
        id_peminjaman='$id_peminjaman',
        id_peminjam='$id_peminjam',
        status_peminjaman='0'";

    $query_input = mysqli_query($koneksi, $sql_peminjaman);

    if ($query_input) {

        $detail_pinjam = "INSERT INTO detail_pinjam SET
            jumlah='$jumlah',
            id_barang='$id_barang',
            id_peminjaman='$id_peminjaman'";

        $q_detail_pinjam = mysqli_query($koneksi, $detail_pinjam);

        if ($q_detail_pinjam) {

            $updateStok = mysqli_query($koneksi,
                "UPDATE barang SET jumlah = jumlah - $jumlah WHERE id_barang='$id_barang'"
            );

            if ($updateStok) {
                mysqli_commit($koneksi);
                echo "<script>alert('Data berhasil disimpan');window.location='?P=peminjaman';</script>";
            } else {
                mysqli_rollback($koneksi);
                echo "Gagal update stok";
            }

        } else {
            mysqli_rollback($koneksi);
            echo "Gagal simpan detail pinjam";
        }

    } else {
        mysqli_rollback($koneksi);
        echo "Gagal simpan peminjaman";
    }
}
?>
        </div>
    </div>

    <div class="col-lg-9">
        <div class="panel panel-primary">
            <div class="panel-heading">Daftar Barang Dipinjam</div>
            <div class="panel-body">

    <div class="table-responsive">

        <table class="table table-bordered table-striped">

                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Peminjaman</th>
                            <th>Tgl.pinjam</th>
                            <th>Nama Peminjam</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Tgl.Kembali</th>
                            <th>Status</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>

<?php
$hari = date('d-m-Y');
$d_peminjaman = "SELECT *, detail_pinjam.jumlah AS jumlah
FROM detail_pinjam
LEFT JOIN peminjaman ON peminjaman.id_peminjaman = detail_pinjam.id_peminjaman
LEFT JOIN barang ON barang.id_barang = detail_pinjam.id_barang
LEFT JOIN peminjam ON peminjam.id_peminjam = peminjaman.id_peminjam";

$d_query = mysqli_query($koneksi, $d_peminjaman);
$no = 1;

while ($data_d = mysqli_fetch_array($d_query)) {
?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $data_d['id_peminjaman'] ?></td>
                            <td><?= $hari ?></td>
                            <td><?= $data_d['nama_peminjam'] ?></td>
                            <td><?= $data_d['nama'] ?></td>
                            <td><?= $data_d['jumlah'] ?></td>
                            <td><?= $data_d['tanggal_kembali'] ?></td>
                            <td>
                                <?php
                                if ($data_d['status_peminjaman'] == '0') {
                                    echo "<span class='label label-danger'>Konfirmasi</span>";
                                } elseif ($data_d['status_peminjaman'] == '1') {
                                    echo "<span class='label label-warning'>Dipinjam</span>";
                                } else {
                                    echo "<span class='label label-success'>Dikembalikan</span>";
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($data_d['status_peminjaman'] == '0') { ?>
                                    <a onclick="return confirm('Apakah Anda Yakin?')"
                                       href="page/proses_peminjaman.php?id_peminjaman=<?= $data_d['id_peminjaman'] ?>"
                                       class="btn btn-sm btn-primary">Proses</a>
                                <?php } ?>
                            </td>
                        </tr>
<?php } ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
