<?php
// KONEKSI DATABASE
$conn = mysqli_connect("localhost","root","","inventaris");

// PROSES SIMPAN DATA
if(isset($_POST['daftar'])){

    
    $nama   = $_POST['nama_peminjam']; 
    $kode   = $_POST['Nip'];
    $alamat = $_POST['alamat'];

    $query = mysqli_query($conn,
        "INSERT INTO peminjam (kode_peminjam,nama_peminjam,alamat)
         VALUES ('$kode','$nama','$alamat')");

    if($query){
        echo "<script>alert('Peminjam berhasil didaftarkan');</script>";
    }else{
        echo "<script>alert('Peminjam gagal didaftarkan');</script>";
    }
}
?>

<div class="panel panel-primary panel-daftar-peminjam">
    <div class="panel-heading">
        <h4 class="panel-title text-center">Daftar Peminjam</h4>
    </div>
    <div class="panel-body">
        <form method="post">

            <div class="form-group">
                <label>Nama Peminjam</label>
                <input type="text" name="nama_peminjam" class="form-control" required>
            </div>

             <div class="form-group">
                <label>Nip</label>
                <input type="text" name="Nip" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" class="form-control" required></textarea>
            </div>

            <button type="submit" name="daftar" class="btn btn-primary btn-block">
                Daftar
            </button>

        </form>
    </div>
</div>
