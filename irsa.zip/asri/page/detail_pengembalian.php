<?php
$id_peminjaman = $_GET['id_peminjaman'];
if (empty($id_peminjaman)) {
  ?>
<script type="text/javascript">
window.location.href = "?P=pengembalian";
</script>
<?php
}
$hari = date('d-m-Y');
$d_peminjaman = "SELECT *,detail_pinjam.jumlah as  jumlah FROM detail_pinjam left join peminjaman on peminjaman.
id_peminjaman = detail_pinjam.id_peminjaman left join barang on barang.
id_barang = detail_pinjam.id_barang Left Join peminjam on peminjam.id_peminjam = peminjaman.id_peminjam WHERE peminjaman.id_peminjaman = '$id_peminjaman'";
$d_query = mysqli_query($koneksi,$d_peminjaman);
$data = mysqli_fetch_array($d_query);
?>
<div class="col-lg-6">
    <div class="panel panel-primary">
        <div class="panel-heading">Konfirmasi Pengembalian Barang</div>
        <div class="panel-body">

            <form action="" method="post">

                <div class="form-group">
                    <label>Kode Peminjaman</label>
                    <input type="text" name="kode_peminjaman" class="form-control" value="<?= $data['id_peminjaman'] ?>"
                        readonly>
                </div>

                <div class=" form-group">
                    <label>Tanggal Peminjaman</label>
                    <input type="text" name="tanggal_pinjam" class="form-control" value="<?= $hari ?>" readonly>
                </div>


                <div class="form-group">
                    <label>Nama Peminjam</label>
                    <input type="text" name="nama_peminjam" class="form-control" value="<?= $data['id_peminjam'] ?>"
                        readonly>
                </div>

                <div class="form-group">
                    <label>Nama Barang</label>
                    <input type="text" name="nama" class="form-control" value="<?= $data['nama'] ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Jumlah</label>
                    <input type="number" name="jumlah" class="form-control" value="<?= $data['jumlah'] ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Tanggal Pengembalian</label>
                    <input type="date" name="tgl_kembali" class="form-control" required>
                </div>

                <div class="form-group">
                    <button type="submit"
        name="simpan"
        class="btn btn-primary btn-md"
        onclick="return confirm('Pastikan barang sudah diterima. Klik OK untuk menyimpan pengembalian.')">
    Simpan
</button>

                    <a href="?P=pengembalian" class="btn btn-default btn-md">Kembali</a>
                </div>
            </form>
        </div>
        <?php
 // LOGIKA SIMPAN + UPDATE STOK
if (isset($_POST['simpan'])) {
    $tgl_kembali = $_POST['tgl_kembali'];

    $query_barang = mysqli_query(
        $koneksi,
        "SELECT id_barang, jumlah FROM detail_pinjam WHERE id_peminjaman='$id_peminjaman'"
    );

    while ($data_barang = mysqli_fetch_array($query_barang)) {
        $id_barang = $data_barang['id_barang'];
        $jumlah    = $data_barang['jumlah'];

        // ✅ TAMBAH STOK (pakai kolom jumlah)
        mysqli_query(
            $koneksi,
            "UPDATE barang SET jumlah = jumlah + $jumlah WHERE id_barang='$id_barang'"
        );
    }

    $sql_pengembalian = "UPDATE peminjaman SET
        tanggal_kembali = '$tgl_kembali',
        status_peminjaman = '2'
        WHERE id_peminjaman='$id_peminjaman'";

    $q_pengembalian = mysqli_query($koneksi, $sql_pengembalian);

    if ($q_pengembalian) {
        echo "<script>window.location.href='?P=pengembalian';</script>";
    } else {
        echo "<div class='alert alert-danger'>Barang Gagal Untuk Diupdate!</div>";
    }
}

        