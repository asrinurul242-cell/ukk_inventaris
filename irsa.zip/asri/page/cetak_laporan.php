<?php
include "../config/koneksi.php";

$tgl_awal   = $_GET['tgl_awal'] ?? '';
$tgl_Sampai = $_GET['tgl_Sampai'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cetak Laporan</title>
     <link href="../dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <div class="row">
        <div class="col-lg-6 col-cetak">
            <center>
                <h2>Laporan Peminjaman</h2>
                periode :
                <?= date('d-m-Y', strtotime($tgl_awal)) ?>
                <b>s/d</b>
                <?= date('d-m-Y', strtotime($tgl_Sampai)) ?>
            </center>
            <hr>
          <br>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Peminjam</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Tgl. Peminjaman</th>
                        <th>Tgl. Pengembalian</th>
                    </tr>
                </thead>
                <tbody>
                     <?php
                     $cari = '';
                    @$tgl_awal = $_GET['tgl_awal'];
                    @$tgl_sampai = $_GET['tgl_sampai'];

                     if (!empty($tgl_awal)) {
                     $cari .="and tanggal_pinjam >= '".$tgl_awal."'";
                     }
                     if (!empty($tgl_Sampai)) {
                      $cari .="and tanggal_pinjam <= '".$tgl_Sampai."'";
                      }
                     //if (empty($tgl_awal) && empty($tgl_Sampai)) {
                      //$cari .="and tanggal_pinjam >= '".$tgl_awal."'and tanggal_pinjam <='".$tgl_Sampai."'";
                     //}
                     $sql =  "SELECT *,detail_pinjam.jumlah as  jumlah FROM detail_pinjam left join peminjaman on peminjaman.id_peminjaman = detail_pinjam.id_peminjaman left join barang on barang.id_barang = detail_pinjam.id_barang 
                     Left Join peminjam on peminjam.id_peminjam = peminjaman.id_peminjam WHERE 1=1 $cari";

                     $query = mysqli_query($koneksi, $sql);
                     $cek = mysqli_num_rows($query);
                     
                     if ($cek > 0) {
                      $no = 1;
                     while ($data = mysqli_fetch_array($query)) {
                     ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data['nama_peminjam'] ?></td>
                        <td><?= $data['nama'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                        <td><?= $data['tanggal_pinjam'] ?></td>
                        <td><?= $data['tanggal_kembali'] ?></td>
                    </tr>
                    <?php
                   }
                    }else {
                     ?>
                    <tr>
                        <td colspan="6">Tidak Ada Data </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<script type="text/javascript">
window.print()
</script>